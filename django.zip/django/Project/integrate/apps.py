from django.apps import AppConfig


class IntegrateConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'integrate'
